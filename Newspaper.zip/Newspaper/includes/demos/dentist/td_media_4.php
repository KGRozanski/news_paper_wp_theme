<?php

//gallery images
td_demo_media::add_image_to_media_gallery('gallery9',                    "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery9.jpg");
td_demo_media::add_image_to_media_gallery('gallery10',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery10.jpg");
td_demo_media::add_image_to_media_gallery('gallery11',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery11.jpg");
td_demo_media::add_image_to_media_gallery('gallery12',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery12.jpg");

//testimonial images
td_demo_media::add_image_to_media_gallery('t-george',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/t-george.jpg");
td_demo_media::add_image_to_media_gallery('t-jon',                      "http://demo_content.tagdiv.com/Newspaper_multi/dentist/t-jon.jpg");
td_demo_media::add_image_to_media_gallery('t-kevin',                    "http://demo_content.tagdiv.com/Newspaper_multi/dentist/t-kevin.jpg");
td_demo_media::add_image_to_media_gallery('t-marcus',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/t-marcus.jpg");
td_demo_media::add_image_to_media_gallery('t-mariana',                  "http://demo_content.tagdiv.com/Newspaper_multi/dentist/t-mariana.jpg");
td_demo_media::add_image_to_media_gallery('t-sandra',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/t-sandra.jpg");