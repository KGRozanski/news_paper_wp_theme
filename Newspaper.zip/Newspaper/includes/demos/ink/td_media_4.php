<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('team_tattoos2',              'http://demo_content.tagdiv.com/Newspaper_multi/ink/team_tattoos2.jpg');
td_demo_media::add_image_to_media_gallery('team_tattoos3',              'http://demo_content.tagdiv.com/Newspaper_multi/ink/team_tattoos3.jpg');
td_demo_media::add_image_to_media_gallery('team_tattoos4',              'http://demo_content.tagdiv.com/Newspaper_multi/ink/team_tattoos4.jpg');
td_demo_media::add_image_to_media_gallery('team_tattoos5',              'http://demo_content.tagdiv.com/Newspaper_multi/ink/team_tattoos5.jpg');

//the shop page
td_demo_media::add_image_to_media_gallery('shop_friendly',              'http://demo_content.tagdiv.com/Newspaper_multi/ink/shop_friendly.jpg');