<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('hero_artists',               'http://demo_content.tagdiv.com/Newspaper_multi/ink/hero_artists.jpg');

//hero
td_demo_media::add_image_to_media_gallery('hero_shop',                  'http://demo_content.tagdiv.com/Newspaper_multi/ink/hero_shop.jpg');
td_demo_media::add_image_to_media_gallery('hero_contact',               'http://demo_content.tagdiv.com/Newspaper_multi/ink/hero_contact.jpg');

//home page
td_demo_media::add_image_to_media_gallery('home_shop',                  'http://demo_content.tagdiv.com/Newspaper_multi/ink/home_shop.jpg');